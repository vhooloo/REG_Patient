<?php
// created: 2013-11-18 05:29:12
$dictionary["Meeting"]["fields"]["reg_treatment_plan_activities_meetings"] = array (
  'name' => 'reg_treatment_plan_activities_meetings',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_activities_meetings',
  'source' => 'non-db',
  'vname' => 'LBL_REG_TREATMENT_PLAN_ACTIVITIES_MEETINGS_FROM_REG_TREATMENT_PLAN_TITLE',
);
