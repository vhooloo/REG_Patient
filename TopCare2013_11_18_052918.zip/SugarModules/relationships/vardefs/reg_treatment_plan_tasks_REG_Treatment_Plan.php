<?php
// created: 2012-11-14 08:48:56
$dictionary["REG_Treatment_Plan"]["fields"]["reg_treatment_plan_tasks"] = array (
  'name' => 'reg_treatment_plan_tasks',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_tasks',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_REG_TREATMENT_PLAN_TASKS_FROM_TASKS_TITLE',
);
