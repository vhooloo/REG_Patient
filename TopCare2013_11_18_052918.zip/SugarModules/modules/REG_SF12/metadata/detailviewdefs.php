<?php
$module_name = 'REG_SF12';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'header',
            'studio' => 'visible',
            'label' => 'LBL_HEADER',
          ),
          1 => 
          array (
            'name' => 'form_id',
            'label' => 'LBL_FORM_ID',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'reg_patient_reg_sf12_name',
            'label' => 'LBL_REG_PATIENT_REG_SF12_FROM_REG_PATIENT_TITLE',
          ),
          1 => 'assigned_user_name',
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'question1',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION1',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'question2',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION2',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'question2a',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION2A',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'question2b',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION2B',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'question3',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION3',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'question3a',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION3A',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'question3b',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION3B',
          ),
        ),
        9 => 
        array (
          0 => 
          array (
            'name' => 'question4',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION4',
          ),
        ),
        10 => 
        array (
          0 => 
          array (
            'name' => 'question4a',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION4A',
          ),
        ),
        11 => 
        array (
          0 => 
          array (
            'name' => 'question4b',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION4B',
          ),
        ),
        12 => 
        array (
          0 => 
          array (
            'name' => 'question5',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION5',
          ),
        ),
        13 => 
        array (
          0 => 
          array (
            'name' => 'question6',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION6',
          ),
        ),
        14 => 
        array (
          0 => 
          array (
            'name' => 'question6a',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION6A',
          ),
        ),
        15 => 
        array (
          0 => 
          array (
            'name' => 'question6b',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION6B',
          ),
        ),
        16 => 
        array (
          0 => 
          array (
            'name' => 'question6c',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION6C',
          ),
        ),
        17 => 
        array (
          0 => 
          array (
            'name' => 'question7',
            'studio' => 'visible',
            'label' => 'LBL_QUESTION7',
          ),
        ),
      ),
    ),
  ),
);
?>
