<?php
 // created: 2013-11-18 05:29:17
$layout_defs["REG_Patient"]["subpanel_setup"]['reg_labresults_reg_patient'] = array (
  'order' => 100,
  'module' => 'REG_LabResults',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_REG_LABRESULTS_REG_PATIENT_FROM_REG_LABRESULTS_TITLE',
  'get_subpanel_data' => 'reg_labresults_reg_patient',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
