<?php
$module_name = 'REG_LabResults';
$listViewDefs [$module_name] = 
array (
  'REG_LABRESULTS_REG_PATIENT_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_REG_LABRESULTS_REG_PATIENT_FROM_REG_PATIENT_TITLE',
    'id' => 'REG_LABRESULTS_REG_PATIENTREG_PATIENT_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'DATE_ENTERED' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => true,
  ),
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
  'UTS_OPIOIDS' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_UTS_OPIOIDS',
    'width' => '10%',
    'default' => true,
  ),
  'UTS_COCAINE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_UTS_COCAINE',
    'width' => '10%',
    'default' => true,
  ),
  'UTS_THC' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_UTS_THC',
    'width' => '10%',
    'default' => true,
  ),
  'UTS_BENZOS' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_UTS_BENZOS',
    'width' => '10%',
    'default' => true,
  ),
  'UTS_METHADONE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_UTS_METHADONE',
    'width' => '10%',
    'default' => true,
  ),
  'UTS_OXYCODONE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_UTS_OXYCODONE',
    'width' => '10%',
    'default' => true,
  ),
  'UTS_HYDROCODONE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_UTS_HYDROCODONE',
    'width' => '10%',
    'default' => true,
  ),
  'UTS_PROPOXYPHENE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_UTS_PROPOXYPHENE',
    'width' => '10%',
    'default' => true,
  ),
  'UTS_BUPRENORPHINE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_UTS_BUPRENORPHINE',
    'width' => '10%',
    'default' => true,
  ),
);
?>
