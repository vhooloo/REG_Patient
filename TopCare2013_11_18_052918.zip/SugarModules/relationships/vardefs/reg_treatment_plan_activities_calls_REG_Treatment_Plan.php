<?php
// created: 2013-11-18 05:29:12
$dictionary["REG_Treatment_Plan"]["fields"]["reg_treatment_plan_activities_calls"] = array (
  'name' => 'reg_treatment_plan_activities_calls',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_activities_calls',
  'source' => 'non-db',
  'vname' => 'LBL_REG_TREATMENT_PLAN_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
