<?php
// created: 2013-11-18 05:29:16
$dictionary["REG_SF12"]["fields"]["reg_patient_reg_sf12"] = array (
  'name' => 'reg_patient_reg_sf12',
  'type' => 'link',
  'relationship' => 'reg_patient_reg_sf12',
  'source' => 'non-db',
  'vname' => 'LBL_REG_PATIENT_REG_SF12_FROM_REG_PATIENT_TITLE',
  'id_name' => 'reg_patient_reg_sf12reg_patient_ida',
);
$dictionary["REG_SF12"]["fields"]["reg_patient_reg_sf12_name"] = array (
  'name' => 'reg_patient_reg_sf12_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_REG_PATIENT_REG_SF12_FROM_REG_PATIENT_TITLE',
  'save' => true,
  'id_name' => 'reg_patient_reg_sf12reg_patient_ida',
  'link' => 'reg_patient_reg_sf12',
  'table' => 'reg_patient',
  'module' => 'REG_Patient',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["REG_SF12"]["fields"]["reg_patient_reg_sf12reg_patient_ida"] = array (
  'name' => 'reg_patient_reg_sf12reg_patient_ida',
  'type' => 'link',
  'relationship' => 'reg_patient_reg_sf12',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_REG_PATIENT_REG_SF12_FROM_REG_SF12_TITLE',
);
