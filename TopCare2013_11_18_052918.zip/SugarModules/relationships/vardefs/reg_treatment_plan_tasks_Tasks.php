<?php
// created: 2012-11-14 08:48:56
$dictionary["Task"]["fields"]["reg_treatment_plan_tasks"] = array (
  'name' => 'reg_treatment_plan_tasks',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_tasks',
  'source' => 'non-db',
  'vname' => 'LBL_REG_TREATMENT_PLAN_TASKS_FROM_REG_TREATMENT_PLAN_TITLE',
  'id_name' => 'reg_treatment_plan_tasksreg_treatment_plan_ida',
);
$dictionary["Task"]["fields"]["reg_treatment_plan_tasks_name"] = array (
  'name' => 'reg_treatment_plan_tasks_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_REG_TREATMENT_PLAN_TASKS_FROM_REG_TREATMENT_PLAN_TITLE',
  'save' => true,
  'id_name' => 'reg_treatment_plan_tasksreg_treatment_plan_ida',
  'link' => 'reg_treatment_plan_tasks',
  'table' => 'reg_treatment_plan',
  'module' => 'REG_Treatment_Plan',
  'rname' => 'name',
);
$dictionary["Task"]["fields"]["reg_treatment_plan_tasksreg_treatment_plan_ida"] = array (
  'name' => 'reg_treatment_plan_tasksreg_treatment_plan_ida',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_tasks',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_REG_TREATMENT_PLAN_TASKS_FROM_TASKS_TITLE',
);
