<?php
// created: 2013-11-18 05:29:16
$dictionary["REG_Patient"]["fields"]["reg_patient_reg_sf12"] = array (
  'name' => 'reg_patient_reg_sf12',
  'type' => 'link',
  'relationship' => 'reg_patient_reg_sf12',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_REG_PATIENT_REG_SF12_FROM_REG_SF12_TITLE',
);
