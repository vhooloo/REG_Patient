<?php
// created: 2013-11-18 05:29:12
$dictionary["REG_Structured_Element"]["fields"]["reg_treatment_plan_reg_structured_element"] = array (
  'name' => 'reg_treatment_plan_reg_structured_element',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_reg_structured_element',
  'source' => 'non-db',
  'vname' => 'LBL_REG_TREATMENT_PLAN_REG_STRUCTURED_ELEMENT_FROM_REG_TREATMENT_PLAN_TITLE',
  'id_name' => 'reg_treatment_plan_reg_structured_elementreg_treatment_plan_ida',
);
$dictionary["REG_Structured_Element"]["fields"]["reg_treatment_plan_reg_structured_element_name"] = array (
  'name' => 'reg_treatment_plan_reg_structured_element_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_REG_TREATMENT_PLAN_REG_STRUCTURED_ELEMENT_FROM_REG_TREATMENT_PLAN_TITLE',
  'save' => true,
  'id_name' => 'reg_treatment_plan_reg_structured_elementreg_treatment_plan_ida',
  'link' => 'reg_treatment_plan_reg_structured_element',
  'table' => 'reg_treatment_plan',
  'module' => 'REG_Treatment_Plan',
  'rname' => 'name',
);
$dictionary["REG_Structured_Element"]["fields"]["reg_treatment_plan_reg_structured_elementreg_treatment_plan_ida"] = array (
  'name' => 'reg_treatment_plan_reg_structured_elementreg_treatment_plan_ida',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_reg_structured_element',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_REG_TREATMENT_PLAN_REG_STRUCTURED_ELEMENT_FROM_REG_STRUCTURED_ELEMENT_TITLE',
);
