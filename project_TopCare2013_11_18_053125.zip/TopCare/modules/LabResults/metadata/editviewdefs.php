<?php
$module_name = 'REG_LabResults';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
        'LBL_EDITVIEW_PANEL1' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 'assigned_user_name',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'reg_labresults_reg_patient_name',
          ),
        ),
      ),
      'lbl_editview_panel1' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'uts_cocaine',
            'label' => 'LBL_UTS_COCAINE',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'uts_hydrocodone',
            'label' => 'LBL_UTS_HYDROCODONE',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'uts_methadone',
            'label' => 'LBL_UTS_METHADONE',
          ),
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'uts_opioids',
            'label' => 'LBL_UTS_OPIOIDS',
          ),
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'uts_oxycodone',
            'label' => 'LBL_UTS_OXYCODONE',
          ),
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'uts_buprenorphine',
            'label' => 'LBL_UTS_BUPRENORPHINE',
          ),
        ),
        6 => 
        array (
          0 => 
          array (
            'name' => 'uts_propoxyphene',
            'label' => 'LBL_UTS_PROPOXYPHENE',
          ),
        ),
        7 => 
        array (
          0 => 
          array (
            'name' => 'uts_thc',
            'label' => 'LBL_UTS_THC',
          ),
        ),
        8 => 
        array (
          0 => 
          array (
            'name' => 'uts_benzos',
            'label' => 'LBL_UTS_BENZOS',
          ),
        ),
      ),
    ),
  ),
);
?>
