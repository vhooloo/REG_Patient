<?php
// created: 2013-11-18 05:29:12
$dictionary["Note"]["fields"]["reg_treatment_plan_notes"] = array (
  'name' => 'reg_treatment_plan_notes',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_notes',
  'source' => 'non-db',
  'vname' => 'LBL_REG_TREATMENT_PLAN_NOTES_FROM_REG_TREATMENT_PLAN_TITLE',
  'id_name' => 'reg_treatment_plan_notesreg_treatment_plan_ida',
);
$dictionary["Note"]["fields"]["reg_treatment_plan_notes_name"] = array (
  'name' => 'reg_treatment_plan_notes_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_REG_TREATMENT_PLAN_NOTES_FROM_REG_TREATMENT_PLAN_TITLE',
  'save' => true,
  'id_name' => 'reg_treatment_plan_notesreg_treatment_plan_ida',
  'link' => 'reg_treatment_plan_notes',
  'table' => 'reg_treatment_plan',
  'module' => 'REG_Treatment_Plan',
  'rname' => 'name',
);
$dictionary["Note"]["fields"]["reg_treatment_plan_notesreg_treatment_plan_ida"] = array (
  'name' => 'reg_treatment_plan_notesreg_treatment_plan_ida',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_notes',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_REG_TREATMENT_PLAN_NOTES_FROM_NOTES_TITLE',
);
