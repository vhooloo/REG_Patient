<?php
 // created: 2013-11-18 05:29:16
$layout_defs["REG_Patient"]["subpanel_setup"]['reg_patient_reg_encounter'] = array (
  'order' => 100,
  'module' => 'REG_Encounter',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_REG_PATIENT_REG_ENCOUNTER_FROM_REG_ENCOUNTER_TITLE',
  'get_subpanel_data' => 'reg_patient_reg_encounter',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
