<?php
// created: 2013-11-18 05:29:17
$dictionary["reg_labresults_reg_patient"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'reg_labresults_reg_patient' => 
    array (
      'lhs_module' => 'REG_Patient',
      'lhs_table' => 'reg_patient',
      'lhs_key' => 'id',
      'rhs_module' => 'REG_LabResults',
      'rhs_table' => 'reg_labresults',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'reg_labresults_reg_patient_c',
      'join_key_lhs' => 'reg_labresults_reg_patientreg_patient_ida',
      'join_key_rhs' => 'reg_labresults_reg_patientreg_labresults_idb',
    ),
  ),
  'table' => 'reg_labresults_reg_patient_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'reg_labresults_reg_patientreg_patient_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'reg_labresults_reg_patientreg_labresults_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'reg_labresults_reg_patientspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'reg_labresults_reg_patient_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'reg_labresults_reg_patientreg_patient_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'reg_labresults_reg_patient_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'reg_labresults_reg_patientreg_labresults_idb',
      ),
    ),
  ),
);