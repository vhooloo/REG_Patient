<?php
// created: 2013-11-18 05:29:12
$dictionary["reg_treatment_plan_reg_structured_element"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'reg_treatment_plan_reg_structured_element' => 
    array (
      'lhs_module' => 'REG_Treatment_Plan',
      'lhs_table' => 'reg_treatment_plan',
      'lhs_key' => 'id',
      'rhs_module' => 'REG_Structured_Element',
      'rhs_table' => 'reg_structured_element',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'reg_treatment_plan_reg_structured_element_c',
      'join_key_lhs' => 'reg_treatment_plan_reg_structured_elementreg_treatment_plan_ida',
      'join_key_rhs' => 'reg_treatm68ecelement_idb',
    ),
  ),
  'table' => 'reg_treatment_plan_reg_structured_element_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'reg_treatment_plan_reg_structured_elementreg_treatment_plan_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'reg_treatm68ecelement_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'reg_treatment_plan_reg_structured_elementspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'reg_treatment_plan_reg_structured_element_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'reg_treatment_plan_reg_structured_elementreg_treatment_plan_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'reg_treatment_plan_reg_structured_element_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'reg_treatm68ecelement_idb',
      ),
    ),
  ),
);