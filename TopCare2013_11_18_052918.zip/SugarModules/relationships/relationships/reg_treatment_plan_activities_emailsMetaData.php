<?php
// created: 2013-11-18 05:29:12
$dictionary["reg_treatment_plan_activities_emails"] = array (
  'relationships' => 
  array (
    'reg_treatment_plan_activities_emails' => 
    array (
      'lhs_module' => 'REG_Treatment_Plan',
      'lhs_table' => 'reg_treatment_plan',
      'lhs_key' => 'id',
      'rhs_module' => 'Emails',
      'rhs_table' => 'emails',
      'rhs_key' => 'parent_id',
      'relationship_type' => 'one-to-many',
      'relationship_role_column' => 'parent_type',
      'relationship_role_column_value' => 'REG_Treatment_Plan',
    ),
  ),
  'fields' => '',
  'indices' => '',
  'table' => '',
);