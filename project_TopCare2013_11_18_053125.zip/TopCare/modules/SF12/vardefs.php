<?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2012 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/

$vardefs = array (
  'fields' => 
  array (
    'question2' => 
    array (
      'required' => false,
      'source' => 'non-db',
      'name' => 'question2',
      'vname' => 'LBL_QUESTION2',
      'type' => 'html',
      'massupdate' => 0,
      'default' => '&lt;p&gt;The following questions are about activities you might do during a typical day.&lt;/p&gt;
&lt;p&gt;Does your health now limit you in these activities? If so, how much?&lt;/p&gt;',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => '255',
      'size' => '20',
      'default_value' => '&lt;p&gt;The following questions are about activities you might do during a typical day.&lt;/p&gt;
&lt;p&gt;Does your health now limit you in these activities? If so, how much?&lt;/p&gt;',
      'studio' => 'visible',
      'dbType' => 'text',
    ),
    'question1' => 
    array (
      'required' => false,
      'name' => 'question1',
      'vname' => 'LBL_QUESTION1',
      'type' => 'radioenum',
      'massupdate' => 0,
      'default' => 'Good',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => 100,
      'size' => '20',
      'options' => 'SF12_Q1_list',
      'studio' => 'visible',
      'dbType' => 'enum',
      'separator' => '<br>',
    ),
    'question2a' => 
    array (
      'required' => false,
      'name' => 'question2a',
      'vname' => 'LBL_QUESTION2A',
      'type' => 'radioenum',
      'massupdate' => 0,
      'default' => 'Yes1',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => 100,
      'size' => '20',
      'options' => 'SF12_Q2a_list',
      'studio' => 'visible',
      'dbType' => 'enum',
      'separator' => '<br>',
    ),
    'question2b' => 
    array (
      'required' => false,
      'name' => 'question2b',
      'vname' => 'LBL_QUESTION2B',
      'type' => 'radioenum',
      'massupdate' => 0,
      'default' => 'Yes1',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => 100,
      'size' => '20',
      'options' => 'SF12_Q2b_list',
      'studio' => 'visible',
      'dbType' => 'enum',
      'separator' => '<br>',
    ),
    'header' => 
    array (
      'required' => false,
      'source' => 'non-db',
      'name' => 'header',
      'vname' => 'LBL_HEADER',
      'type' => 'html',
      'massupdate' => 0,
      'default' => '&lt;table style=&quot;width: 1053px;&quot; border=&quot;0&quot; cellspacing=&quot;0&quot; cellpadding=&quot;0&quot;&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td colspan=&quot;3&quot; valign=&quot;bottom&quot; width=&quot;457&quot;&gt;
&lt;p&gt;&lt;strong&gt;This survey asks for your views about your health. This information will help you keep track of how you feel and how well you are able to do your usual activities.&lt;/strong&gt;&lt;/p&gt;
&lt;/td&gt;
&lt;td colspan=&quot;2&quot; valign=&quot;bottom&quot; width=&quot;263&quot;&gt;&nbsp;&lt;/td&gt;
&lt;td colspan=&quot;3&quot; width=&quot;333&quot;&gt;
&lt;p&gt;&nbsp;&lt;/p&gt;
&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td colspan=&quot;3&quot; valign=&quot;bottom&quot; width=&quot;457&quot;&gt;
&lt;p&gt;&lt;strong&gt;Answer every question by selecting the answer as indicated. If you are unsure about how to answer a question, please give the best answer you can.&lt;/strong&gt;&lt;/p&gt;
&lt;/td&gt;
&lt;/tr&gt;
&lt;/tbody&gt;
&lt;/table&gt;',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => '255',
      'size' => '20',
      'default_value' => '&lt;table style=&quot;width: 1053px;&quot; border=&quot;0&quot; cellspacing=&quot;0&quot; cellpadding=&quot;0&quot;&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td colspan=&quot;3&quot; valign=&quot;bottom&quot; width=&quot;457&quot;&gt;
&lt;p&gt;&lt;strong&gt;This survey asks for your views about your health. This information will help you keep track of how you feel and how well you are able to do your usual activities.&lt;/strong&gt;&lt;/p&gt;
&lt;/td&gt;
&lt;td colspan=&quot;2&quot; valign=&quot;bottom&quot; width=&quot;263&quot;&gt;&nbsp;&lt;/td&gt;
&lt;td colspan=&quot;3&quot; width=&quot;333&quot;&gt;
&lt;p&gt;&nbsp;&lt;/p&gt;
&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td colspan=&quot;3&quot; valign=&quot;bottom&quot; width=&quot;457&quot;&gt;
&lt;p&gt;&lt;strong&gt;Answer every question by selecting the answer as indicated. If you are unsure about how to answer a question, please give the best answer you can.&lt;/strong&gt;&lt;/p&gt;
&lt;/td&gt;
&lt;/tr&gt;
&lt;/tbody&gt;
&lt;/table&gt;',
      'studio' => 'visible',
      'dbType' => 'text',
    ),
    'question3' => 
    array (
      'required' => false,
      'source' => 'non-db',
      'name' => 'question3',
      'vname' => 'LBL_QUESTION3',
      'type' => 'html',
      'massupdate' => 0,
      'default' => '&lt;p&gt;3. During the past 4 weeks, have you had any of the following problems with your work or other regular daily activities as a result of your physical health?&lt;/p&gt;',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => '255',
      'size' => '20',
      'default_value' => '&lt;p&gt;3. During the past 4 weeks, have you had any of the following problems with your work or other regular daily activities as a result of your physical health?&lt;/p&gt;',
      'studio' => 'visible',
      'dbType' => 'text',
    ),
    'Question3a' => 
    array (
      'required' => false,
      'name' => 'Question3a',
      'vname' => 'LBL_QUESTION3A',
      'type' => 'radioenum',
      'massupdate' => 0,
      'default' => 'Yes',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => 100,
      'size' => '20',
      'options' => 'TC_YesNo_list',
      'studio' => 'visible',
      'dbType' => 'enum',
      'separator' => '<br>',
    ),
    'question3b' => 
    array (
      'required' => false,
      'name' => 'question3b',
      'vname' => 'LBL_QUESTION3B',
      'type' => 'radioenum',
      'massupdate' => 0,
      'default' => 'Yes',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => 100,
      'size' => '20',
      'options' => 'TC_YesNo_list',
      'studio' => 'visible',
      'dbType' => 'enum',
      'separator' => '<br>',
    ),
    'question4a' => 
    array (
      'required' => false,
      'name' => 'question4a',
      'vname' => 'LBL_QUESTION4A',
      'type' => 'radioenum',
      'massupdate' => 0,
      'default' => 'Yes',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => 100,
      'size' => '20',
      'options' => 'TC_YesNo_list',
      'studio' => 'visible',
      'dbType' => 'enum',
      'separator' => '<br>',
    ),
    'question4b' => 
    array (
      'required' => false,
      'name' => 'question4b',
      'vname' => 'LBL_QUESTION4B',
      'type' => 'radioenum',
      'massupdate' => 0,
      'default' => 'Yes',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => 100,
      'size' => '20',
      'options' => 'TC_YesNo_list',
      'studio' => 'visible',
      'dbType' => 'enum',
      'separator' => '<br>',
    ),
    'question5' => 
    array (
      'required' => false,
      'name' => 'question5',
      'vname' => 'LBL_QUESTION5',
      'type' => 'enum',
      'massupdate' => 0,
      'default' => 'Op1',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => 100,
      'size' => '20',
      'options' => 'question5_list',
      'studio' => 'visible',
      'dependency' => false,
    ),
    'question6a' => 
    array (
      'required' => false,
      'name' => 'question6a',
      'vname' => 'LBL_QUESTION6A',
      'type' => 'enum',
      'massupdate' => 0,
      'default' => 'Op1',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => 100,
      'size' => '20',
      'options' => 'TC_TimeOption_list',
      'studio' => 'visible',
      'dependency' => false,
    ),
    'question6b' => 
    array (
      'required' => false,
      'name' => 'question6b',
      'vname' => 'LBL_QUESTION6B',
      'type' => 'enum',
      'massupdate' => 0,
      'default' => 'Op1',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => 100,
      'size' => '20',
      'options' => 'TC_TimeOption_list',
      'studio' => 'visible',
      'dependency' => false,
    ),
    'question6c' => 
    array (
      'required' => false,
      'name' => 'question6c',
      'vname' => 'LBL_QUESTION6C',
      'type' => 'enum',
      'massupdate' => 0,
      'default' => 'Op1',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => 100,
      'size' => '20',
      'options' => 'TC_TimeOption_list',
      'studio' => 'visible',
      'dependency' => false,
    ),
    'question7' => 
    array (
      'required' => false,
      'name' => 'question7',
      'vname' => 'LBL_QUESTION7',
      'type' => 'enum',
      'massupdate' => 0,
      'default' => 'Op1',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => 100,
      'size' => '20',
      'options' => 'TC_TimeOption_list',
      'studio' => 'visible',
      'dependency' => false,
    ),
    'question4' => 
    array (
      'required' => false,
      'source' => 'non-db',
      'name' => 'question4',
      'vname' => 'LBL_QUESTION4',
      'type' => 'html',
      'massupdate' => 0,
      'default' => '&lt;p&gt;4. During the past 4 weeks, have you had any of the following problems with your work or other regular daily activities as a result of any emotional problems (such as feeling depressed or anxious)?&lt;/p&gt;',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => '255',
      'size' => '20',
      'default_value' => '&lt;p&gt;4. During the past 4 weeks, have you had any of the following problems with your work or other regular daily activities as a result of any emotional problems (such as feeling depressed or anxious)?&lt;/p&gt;',
      'studio' => 'visible',
      'dbType' => 'text',
    ),
    'question6' => 
    array (
      'required' => false,
      'source' => 'non-db',
      'name' => 'question6',
      'vname' => 'LBL_QUESTION6',
      'type' => 'html',
      'massupdate' => 0,
      'default' => '&lt;table style=&quot;width: 1053px;&quot; border=&quot;0&quot; cellspacing=&quot;0&quot; cellpadding=&quot;0&quot;&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td colspan=&quot;3&quot; width=&quot;457&quot;&gt;
&lt;p&gt;6. These questions are about how you feel and how things have been with you during the past 4 weeks. For each question, please give the one answer that comes closest to the way you have been feeling.&lt;br /&gt;How much of the time during the past 4 weeks...&lt;/p&gt;
&lt;/td&gt;
&lt;td colspan=&quot;2&quot; width=&quot;263&quot;&gt;
&lt;p&gt;&nbsp;&lt;/p&gt;
&lt;/td&gt;
&lt;td colspan=&quot;3&quot; width=&quot;333&quot;&gt;
&lt;p&gt;&nbsp;&lt;/p&gt;
&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td colspan=&quot;3&quot; width=&quot;457&quot;&gt;
&lt;p&gt;&nbsp;&lt;/p&gt;
&lt;/td&gt;
&lt;/tr&gt;
&lt;/tbody&gt;
&lt;/table&gt;',
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => '255',
      'size' => '20',
      'default_value' => '&lt;table style=&quot;width: 1053px;&quot; border=&quot;0&quot; cellspacing=&quot;0&quot; cellpadding=&quot;0&quot;&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td colspan=&quot;3&quot; width=&quot;457&quot;&gt;
&lt;p&gt;6. These questions are about how you feel and how things have been with you during the past 4 weeks. For each question, please give the one answer that comes closest to the way you have been feeling.&lt;br /&gt;How much of the time during the past 4 weeks...&lt;/p&gt;
&lt;/td&gt;
&lt;td colspan=&quot;2&quot; width=&quot;263&quot;&gt;
&lt;p&gt;&nbsp;&lt;/p&gt;
&lt;/td&gt;
&lt;td colspan=&quot;3&quot; width=&quot;333&quot;&gt;
&lt;p&gt;&nbsp;&lt;/p&gt;
&lt;/td&gt;
&lt;/tr&gt;
&lt;tr&gt;
&lt;td colspan=&quot;3&quot; width=&quot;457&quot;&gt;
&lt;p&gt;&nbsp;&lt;/p&gt;
&lt;/td&gt;
&lt;/tr&gt;
&lt;/tbody&gt;
&lt;/table&gt;',
      'studio' => 'visible',
      'dbType' => 'text',
    ),
    'name' => 
    array (
      'name' => 'name',
      'vname' => 'LBL_NAME',
      'type' => 'name',
      'link' => true,
      'dbType' => 'varchar',
      'len' => '255',
      'unified_search' => false,
      'full_text_search' => 
      array (
        'boost' => 3,
      ),
      'required' => false,
      'importable' => 'false',
      'duplicate_merge' => 'disabled',
      'merge_filter' => 'disabled',
      'massupdate' => 0,
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'size' => '20',
    ),
    'form_id' => 
    array (
      'required' => true,
      'name' => 'form_id',
      'vname' => 'LBL_FORM_ID',
      'type' => 'varchar',
      'massupdate' => 0,
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => true,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => '255',
      'size' => '20',
    ),
  ),
  'relationships' => 
  array (
  ),
);