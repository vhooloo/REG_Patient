<?php
// created: 2013-11-18 05:29:12
$dictionary["REG_Treatment_Plan"]["fields"]["reg_treatment_plan_reg_patient"] = array (
  'name' => 'reg_treatment_plan_reg_patient',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_reg_patient',
  'source' => 'non-db',
  'vname' => 'LBL_REG_TREATMENT_PLAN_REG_PATIENT_FROM_REG_PATIENT_TITLE',
  'id_name' => 'reg_treatment_plan_reg_patientreg_patient_ida',
);
$dictionary["REG_Treatment_Plan"]["fields"]["reg_treatment_plan_reg_patient_name"] = array (
  'name' => 'reg_treatment_plan_reg_patient_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_REG_TREATMENT_PLAN_REG_PATIENT_FROM_REG_PATIENT_TITLE',
  'save' => true,
  'id_name' => 'reg_treatment_plan_reg_patientreg_patient_ida',
  'link' => 'reg_treatment_plan_reg_patient',
  'table' => 'reg_patient',
  'module' => 'REG_Patient',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["REG_Treatment_Plan"]["fields"]["reg_treatment_plan_reg_patientreg_patient_ida"] = array (
  'name' => 'reg_treatment_plan_reg_patientreg_patient_ida',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_reg_patient',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_REG_TREATMENT_PLAN_REG_PATIENT_FROM_REG_TREATMENT_PLAN_TITLE',
);
