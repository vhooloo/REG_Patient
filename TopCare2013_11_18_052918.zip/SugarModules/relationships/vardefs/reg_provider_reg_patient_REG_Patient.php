<?php
// created: 2013-11-18 05:29:16
$dictionary["REG_Patient"]["fields"]["reg_provider_reg_patient"] = array (
  'name' => 'reg_provider_reg_patient',
  'type' => 'link',
  'relationship' => 'reg_provider_reg_patient',
  'source' => 'non-db',
  'vname' => 'LBL_REG_PROVIDER_REG_PATIENT_FROM_REG_PROVIDER_TITLE',
  'id_name' => 'reg_provider_reg_patientreg_provider_ida',
);
$dictionary["REG_Patient"]["fields"]["reg_provider_reg_patient_name"] = array (
  'name' => 'reg_provider_reg_patient_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_REG_PROVIDER_REG_PATIENT_FROM_REG_PROVIDER_TITLE',
  'save' => true,
  'id_name' => 'reg_provider_reg_patientreg_provider_ida',
  'link' => 'reg_provider_reg_patient',
  'table' => 'reg_provider',
  'module' => 'REG_Provider',
  'rname' => 'name',
);
$dictionary["REG_Patient"]["fields"]["reg_provider_reg_patientreg_provider_ida"] = array (
  'name' => 'reg_provider_reg_patientreg_provider_ida',
  'type' => 'link',
  'relationship' => 'reg_provider_reg_patient',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_REG_PROVIDER_REG_PATIENT_FROM_REG_PATIENT_TITLE',
);
