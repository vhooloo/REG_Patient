<?php
 // created: 2013-11-18 05:29:12
$layout_defs["REG_Treatment_Plan"]["subpanel_setup"]['reg_treatment_plan_reg_structured_element'] = array (
  'order' => 100,
  'module' => 'REG_Structured_Element',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_REG_TREATMENT_PLAN_REG_STRUCTURED_ELEMENT_FROM_REG_STRUCTURED_ELEMENT_TITLE',
  'get_subpanel_data' => 'reg_treatment_plan_reg_structured_element',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
