<?php
// created: 2013-11-18 05:29:12
$dictionary["REG_Treatment_Plan"]["fields"]["reg_treatment_plan_activities_emails"] = array (
  'name' => 'reg_treatment_plan_activities_emails',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_activities_emails',
  'source' => 'non-db',
  'vname' => 'LBL_REG_TREATMENT_PLAN_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE',
);
