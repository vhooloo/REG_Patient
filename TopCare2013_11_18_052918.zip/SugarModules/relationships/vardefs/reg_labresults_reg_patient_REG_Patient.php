<?php
// created: 2013-11-18 05:29:17
$dictionary["REG_Patient"]["fields"]["reg_labresults_reg_patient"] = array (
  'name' => 'reg_labresults_reg_patient',
  'type' => 'link',
  'relationship' => 'reg_labresults_reg_patient',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_REG_LABRESULTS_REG_PATIENT_FROM_REG_LABRESULTS_TITLE',
);
