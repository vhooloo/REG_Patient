<?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2012 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo. If the display of the logo is not reasonably feasible for
 * technical reasons, the Appropriate Legal Notices must display the words
 * "Powered by SugarCRM".
 ********************************************************************************/


$app_list_strings['moduleList']['REG_Patient'] = 'Patient';
$app_list_strings['moduleList']['REG_SF12'] = 'SF12';
$app_list_strings['moduleList']['REG_SF121'] = 'SF12';
$app_list_strings['moduleList']['REG_Treatment_Plan'] = 'Treatment Plan';
$app_list_strings['moduleList']['REG_Treatment_Plan_'] = 'Treatment Plan';
$app_list_strings['moduleList']['REG_Provider'] = 'Provider';
$app_list_strings['moduleList']['REG_Encounter'] = 'Encounter';
$app_list_strings['moduleList']['REG_Structured_Element'] = 'Structured Element';
$app_list_strings['moduleList']['REG_LabResults'] = 'Lab Results';
$app_list_strings['SF12_Q1_list']['Excellent'] = 'Excellent';
$app_list_strings['SF12_Q1_list']['VeryGood'] = 'Very Good';
$app_list_strings['SF12_Q1_list']['Good'] = 'Good';
$app_list_strings['SF12_Q1_list']['Fair'] = 'Fair';
$app_list_strings['SF12_Q1_list']['Poor'] = 'Poort';
$app_list_strings['SF12_Q2a_list']['Yes1'] = 'Yes, Limited a Lot';
$app_list_strings['SF12_Q2a_list']['Yes2'] = 'Yes, Limited a Little';
$app_list_strings['SF12_Q2a_list']['No'] = 'No, Not Limited at All';
$app_list_strings['SF12_Q2b_list']['Yes1'] = 'Yes, Limited a Lot';
$app_list_strings['SF12_Q2b_list']['Yes2'] = 'Yes, Limited a Little';
$app_list_strings['SF12_Q2b_list']['No'] = 'No, Not limited at all';
$app_list_strings['TC_YesNo_list']['Yes'] = 'Yes';
$app_list_strings['TC_YesNo_list']['No'] = 'No';
$app_list_strings['question5_list']['Op1'] = 'Not at all';
$app_list_strings['question5_list']['Op2'] = 'A Little bit';
$app_list_strings['question5_list']['Op3'] = 'Modelrately';
$app_list_strings['question5_list']['Op4'] = 'Quite a bit';
$app_list_strings['question5_list']['Op5'] = 'Extremely';
$app_list_strings['TC_TimeOption_list']['Op1'] = 'All of the time';
$app_list_strings['TC_TimeOption_list']['Op2'] = 'Most of the time';
$app_list_strings['TC_TimeOption_list']['Op5'] = 'A good bit of the time';
$app_list_strings['TC_TimeOption_list']['Op3'] = 'Some of the time';
$app_list_strings['TC_TimeOption_list']['Op4'] = 'A little of the time';
$app_list_strings['TC_TimeOption_list']['Op6'] = 'None of the time';
$app_list_strings['ethnicity_list']['Hispanic'] = 'Hispanic / Latino';
$app_list_strings['ethnicity_list']['NonHispanic'] = 'Non Hispanic / Non Latino';
$app_list_strings['race_list']['African'] = 'African';
$app_list_strings['race_list']['Asian'] = 'Asian';
$app_list_strings['race_list']['Hispanic'] = 'Hispanic';
$app_list_strings['race_list']['Caucasian'] = 'Caucasian';
$app_list_strings['race_list']['AlaskaNative'] = 'Alaska Native';
$app_list_strings['reg_treatment_plan_type_dom']['Administration'] = 'Administration';
$app_list_strings['reg_treatment_plan_type_dom']['Product'] = 'Product';
$app_list_strings['reg_treatment_plan_type_dom']['User'] = 'User';
$app_list_strings['reg_treatment_plan_status_dom']['New'] = 'New';
$app_list_strings['reg_treatment_plan_status_dom']['Assigned'] = 'Assigned';
$app_list_strings['reg_treatment_plan_status_dom']['Closed'] = 'Closed';
$app_list_strings['reg_treatment_plan_status_dom']['Pending Input'] = 'Pending Input';
$app_list_strings['reg_treatment_plan_status_dom']['Rejected'] = 'Rejected';
$app_list_strings['reg_treatment_plan_status_dom']['Duplicate'] = 'Duplicate';
$app_list_strings['reg_treatment_plan_priority_dom']['P1'] = 'High';
$app_list_strings['reg_treatment_plan_priority_dom']['P2'] = 'Medium';
$app_list_strings['reg_treatment_plan_priority_dom']['P3'] = 'Low';
$app_list_strings['reg_treatment_plan_resolution_dom'][''] = '';
$app_list_strings['reg_treatment_plan_resolution_dom']['Accepted'] = 'Accepted';
$app_list_strings['reg_treatment_plan_resolution_dom']['Duplicate'] = 'Duplicate';
$app_list_strings['reg_treatment_plan_resolution_dom']['Closed'] = 'Closed';
$app_list_strings['reg_treatment_plan_resolution_dom']['Out of Date'] = 'Out of Date';
$app_list_strings['reg_treatment_plan_resolution_dom']['Invalid'] = 'Invalid';
$app_list_strings['reg_treatment_plancategory_dom'][''] = '';
$app_list_strings['reg_treatment_plancategory_dom']['Marketing'] = 'Marketing';
$app_list_strings['reg_treatment_plancategory_dom']['Knowledege Base'] = 'Knowledge Base';
$app_list_strings['reg_treatment_plancategory_dom']['Sales'] = 'Sales';
$app_list_strings['reg_treatment_plansubcategory_dom'][''] = '';
$app_list_strings['reg_treatment_plansubcategory_dom']['Marketing Collateral'] = 'Marketing Collateral';
$app_list_strings['reg_treatment_plansubcategory_dom']['Product Brochures'] = 'Product Brochures';
$app_list_strings['reg_treatment_plansubcategory_dom']['FAQ'] = 'FAQ';
$app_list_strings['reg_treatment_planstatus_dom']['Active'] = 'Active';
$app_list_strings['reg_treatment_planstatus_dom']['Draft'] = 'Draft';
$app_list_strings['reg_treatment_planstatus_dom']['FAQ'] = 'FAQ';
$app_list_strings['reg_treatment_planstatus_dom']['Expired'] = 'Expired';
$app_list_strings['reg_treatment_planstatus_dom']['Under Review'] = 'Under Review';
$app_list_strings['reg_treatment_planstatus_dom']['Pending'] = 'Pending';
$app_list_strings['reg_provider_type_dom'][''] = '';
$app_list_strings['reg_provider_type_dom']['Analyst'] = 'Analyst';
$app_list_strings['reg_provider_type_dom']['Competitor'] = 'Competitor';
$app_list_strings['reg_provider_type_dom']['Customer'] = 'Customer';
$app_list_strings['reg_provider_type_dom']['Integrator'] = 'Integrator';
$app_list_strings['reg_provider_type_dom']['Investor'] = 'Investor';
$app_list_strings['reg_provider_type_dom']['Partner'] = 'Partner';
$app_list_strings['reg_provider_type_dom']['Press'] = 'Press';
$app_list_strings['reg_provider_type_dom']['Prospect'] = 'Prospect';
$app_list_strings['reg_provider_type_dom']['Reseller'] = 'Reseller';
$app_list_strings['reg_provider_type_dom']['Other'] = 'Other';
$app_list_strings['parent_type_display']['REG_Treatment_Plan'] = 'Treatment Plan';
$app_list_strings['record_type_display']['REG_Treatment_Plan'] = 'Treatment Plan';
$app_list_strings['record_type_display_notes']['REG_Treatment_Plan'] = 'Treatment Plan';
$app_list_strings['reg_encounter_category_dom'][''] = '';
$app_list_strings['reg_encounter_category_dom']['Marketing'] = 'Marketing';
$app_list_strings['reg_encounter_category_dom']['Knowledege Base'] = 'Knowledge Base';
$app_list_strings['reg_encounter_category_dom']['Sales'] = 'Sales';
$app_list_strings['reg_encounter_subcategory_dom'][''] = '';
$app_list_strings['reg_encounter_subcategory_dom']['Marketing Collateral'] = 'Marketing Collateral';
$app_list_strings['reg_encounter_subcategory_dom']['Product Brochures'] = 'Product Brochures';
$app_list_strings['reg_encounter_subcategory_dom']['FAQ'] = 'FAQ';
$app_list_strings['reg_encounter_status_dom']['Active'] = 'Active';
$app_list_strings['reg_encounter_status_dom']['Draft'] = 'Draft';
$app_list_strings['reg_encounter_status_dom']['FAQ'] = 'FAQ';
$app_list_strings['reg_encounter_status_dom']['Expired'] = 'Expired';
$app_list_strings['reg_encounter_status_dom']['Under Review'] = 'Under Review';
$app_list_strings['reg_encounter_status_dom']['Pending'] = 'Pending';
$app_list_strings['frequency_list']['Daily'] = 'Daily';
$app_list_strings['frequency_list']['Weekly'] = 'Weekly';
$app_list_strings['frequency_list']['Fortnightly'] = 'Fortnightly';
$app_list_strings['frequency_list']['Monthly'] = 'Monthly';
$app_list_strings['frequency_list']['Quarterly'] = 'Quarterly';
$app_list_strings['frequency_list']['Yearly'] = 'Yearly';
$app_list_strings['type_list']['RoutineUTS'] = 'Routine UTS';
$app_list_strings['type_list']['RandomUTS'] = 'Random UTS';
$app_list_strings['type_list']['RoutinePillCount'] = 'Routine PillCount';
$app_list_strings['type_list']['RandomPillCount'] = 'Random PillCount';
$app_list_strings['sestate_list']['Open'] = 'Open';
$app_list_strings['sestate_list']['Confirmed'] = 'Confirmed';
$app_list_strings['sestate_list']['Abandoned'] = 'Abandoned';
