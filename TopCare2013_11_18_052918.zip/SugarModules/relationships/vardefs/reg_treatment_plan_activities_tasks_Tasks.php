<?php
// created: 2013-11-18 05:29:12
$dictionary["Task"]["fields"]["reg_treatment_plan_activities_tasks"] = array (
  'name' => 'reg_treatment_plan_activities_tasks',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_activities_tasks',
  'source' => 'non-db',
  'vname' => 'LBL_REG_TREATMENT_PLAN_ACTIVITIES_TASKS_FROM_REG_TREATMENT_PLAN_TITLE',
);
