<?php
// created: 2012-11-14 08:48:57
$dictionary["REG_Provider"]["fields"]["reg_patient_reg_provider"] = array (
  'name' => 'reg_patient_reg_provider',
  'type' => 'link',
  'relationship' => 'reg_patient_reg_provider',
  'source' => 'non-db',
  'vname' => 'LBL_REG_PATIENT_REG_PROVIDER_FROM_REG_PATIENT_TITLE',
  'id_name' => 'reg_patient_reg_providerreg_patient_ida',
);
$dictionary["REG_Provider"]["fields"]["reg_patient_reg_provider_name"] = array (
  'name' => 'reg_patient_reg_provider_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_REG_PATIENT_REG_PROVIDER_FROM_REG_PATIENT_TITLE',
  'save' => true,
  'id_name' => 'reg_patient_reg_providerreg_patient_ida',
  'link' => 'reg_patient_reg_provider',
  'table' => 'reg_patient',
  'module' => 'REG_Patient',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["REG_Provider"]["fields"]["reg_patient_reg_providerreg_patient_ida"] = array (
  'name' => 'reg_patient_reg_providerreg_patient_ida',
  'type' => 'link',
  'relationship' => 'reg_patient_reg_provider',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_REG_PATIENT_REG_PROVIDER_FROM_REG_PATIENT_TITLE',
);
