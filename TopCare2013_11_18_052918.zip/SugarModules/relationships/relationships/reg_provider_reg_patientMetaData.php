<?php
// created: 2013-11-18 05:29:16
$dictionary["reg_provider_reg_patient"] = array (
  'true_relationship_type' => 'one-to-many',
  'relationships' => 
  array (
    'reg_provider_reg_patient' => 
    array (
      'lhs_module' => 'REG_Provider',
      'lhs_table' => 'reg_provider',
      'lhs_key' => 'id',
      'rhs_module' => 'REG_Patient',
      'rhs_table' => 'reg_patient',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'reg_provider_reg_patient_c',
      'join_key_lhs' => 'reg_provider_reg_patientreg_provider_ida',
      'join_key_rhs' => 'reg_provider_reg_patientreg_patient_idb',
    ),
  ),
  'table' => 'reg_provider_reg_patient_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'reg_provider_reg_patientreg_provider_ida',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'reg_provider_reg_patientreg_patient_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'reg_provider_reg_patientspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'reg_provider_reg_patient_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'reg_provider_reg_patientreg_provider_ida',
      ),
    ),
    2 => 
    array (
      'name' => 'reg_provider_reg_patient_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'reg_provider_reg_patientreg_patient_idb',
      ),
    ),
  ),
);