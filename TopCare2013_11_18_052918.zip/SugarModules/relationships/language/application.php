<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$app_list_strings['parent_type_display']['REG_Treatment_Plan'] = 'Treatment Plan';
$app_list_strings['record_type_display']['REG_Treatment_Plan'] = 'Treatment Plan';
$app_list_strings['record_type_display_notes']['REG_Treatment_Plan'] = 'Treatment Plan';
