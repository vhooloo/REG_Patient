<?php
// created: 2012-11-14 08:48:57
$dictionary["REG_Patient"]["fields"]["reg_patient_reg_provider"] = array (
  'name' => 'reg_patient_reg_provider',
  'type' => 'link',
  'relationship' => 'reg_patient_reg_provider',
  'source' => 'non-db',
  'vname' => 'LBL_REG_PATIENT_REG_PROVIDER_FROM_REG_PROVIDER_TITLE',
  'id_name' => 'reg_patient_reg_providerreg_provider_idb',
);
$dictionary["REG_Patient"]["fields"]["reg_patient_reg_provider_name"] = array (
  'name' => 'reg_patient_reg_provider_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_REG_PATIENT_REG_PROVIDER_FROM_REG_PROVIDER_TITLE',
  'save' => true,
  'id_name' => 'reg_patient_reg_providerreg_provider_idb',
  'link' => 'reg_patient_reg_provider',
  'table' => 'reg_provider',
  'module' => 'REG_Provider',
  'rname' => 'name',
);
$dictionary["REG_Patient"]["fields"]["reg_patient_reg_providerreg_provider_idb"] = array (
  'name' => 'reg_patient_reg_providerreg_provider_idb',
  'type' => 'link',
  'relationship' => 'reg_patient_reg_provider',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_REG_PATIENT_REG_PROVIDER_FROM_REG_PROVIDER_TITLE',
);
