<?php
// created: 2013-11-18 05:29:12
$dictionary["REG_Treatment_Plan"]["fields"]["reg_treatment_plan_reg_structured_element"] = array (
  'name' => 'reg_treatment_plan_reg_structured_element',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_reg_structured_element',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_REG_TREATMENT_PLAN_REG_STRUCTURED_ELEMENT_FROM_REG_STRUCTURED_ELEMENT_TITLE',
);
