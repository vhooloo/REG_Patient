<?php
// created: 2013-11-18 05:29:12
$dictionary["reg_treatment_plan_activities_tasks"] = array (
  'relationships' => 
  array (
    'reg_treatment_plan_activities_tasks' => 
    array (
      'lhs_module' => 'REG_Treatment_Plan',
      'lhs_table' => 'reg_treatment_plan',
      'lhs_key' => 'id',
      'rhs_module' => 'Tasks',
      'rhs_table' => 'tasks',
      'rhs_key' => 'parent_id',
      'relationship_type' => 'one-to-many',
      'relationship_role_column' => 'parent_type',
      'relationship_role_column_value' => 'REG_Treatment_Plan',
    ),
  ),
  'fields' => '',
  'indices' => '',
  'table' => '',
);