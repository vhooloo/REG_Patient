<?php
// created: 2013-11-18 05:29:16
$dictionary["REG_Provider"]["fields"]["reg_provider_reg_patient"] = array (
  'name' => 'reg_provider_reg_patient',
  'type' => 'link',
  'relationship' => 'reg_provider_reg_patient',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_REG_PROVIDER_REG_PATIENT_FROM_REG_PATIENT_TITLE',
);
