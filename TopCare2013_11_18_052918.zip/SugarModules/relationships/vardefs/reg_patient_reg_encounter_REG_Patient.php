<?php
// created: 2013-11-18 05:29:17
$dictionary["REG_Patient"]["fields"]["reg_patient_reg_encounter"] = array (
  'name' => 'reg_patient_reg_encounter',
  'type' => 'link',
  'relationship' => 'reg_patient_reg_encounter',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_REG_PATIENT_REG_ENCOUNTER_FROM_REG_ENCOUNTER_TITLE',
);
