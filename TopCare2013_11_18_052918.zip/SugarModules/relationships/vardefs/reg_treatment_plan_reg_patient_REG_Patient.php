<?php
// created: 2013-11-18 05:29:12
$dictionary["REG_Patient"]["fields"]["reg_treatment_plan_reg_patient"] = array (
  'name' => 'reg_treatment_plan_reg_patient',
  'type' => 'link',
  'relationship' => 'reg_treatment_plan_reg_patient',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_REG_TREATMENT_PLAN_REG_PATIENT_FROM_REG_TREATMENT_PLAN_TITLE',
);
